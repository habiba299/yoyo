---
name: Issue Template
about: Generic issue template.
title: ''
labels: ''
assignees: ''

---

<!-- This project is a Proof Of Concept and offers no support.  If you have an issue with the code, then the assumption is made that you will figure it out yourself in the process of incorporating its ideas into your own code. -->

<!-- It is also well known that Bootstrap, as a framework, is highly opinionated, and as such will attract much debate ... this is not the forum for that and recommendations to change the way things are written in this work will be, for the most, ignored.  Opinions on this specific code, e.g. this color instead of that color, will not be tolerated – you will be blocked. You are however very welcome to fork from here (see: https://docs.github.com/en/get-started/quickstart/fork-a-repo) and change to your heart's content. -->

<!-- If you however find a typo or other logic error in the code then I would much appreciate you pointing out the error, and if appropriate suggested code to correct the error. -->

<!-- >>>>> You may replace these comments with your issue description. <<<<< -->

